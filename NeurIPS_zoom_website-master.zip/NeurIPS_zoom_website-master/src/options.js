const noop = () => {}

export default {
  /**
   * To be able to grab and drag the image for extra zoom-in.
   * @type {boolean}
   */
  enableGrab: true,

  /**
   * Preload zoomable images.
   * @type {boolean}
   */
  preloadImage: false,

  /**
   * Close the zoomed image when browser window is resized.
   * @type {boolean}
   */
  closeOnWindowResize: true,

  /**
   * Transition duration in seconds.
   * @type {number}
   */
  transitionDuration: 0.4,

  /**
   * Transition timing function.
   * @type {string}
   */
  transitionTimingFunction: 'cubic-bezier(0.4, 0, 0, 1)',

  /**
   * Overlay background color.
   * @type {string}
   */
  bgColor: 'rgb(255, 255, 255)',

  /**
   * Overlay background opacity.
   * @type {number}
   */
  bgOpacity: 1,

  /**
   * The base scale factor for zooming. By default scale to fit the window.
   * @type {number}
   */
  scaleBase: 0.5,

  /**
   * The additional scale factor when grabbing the image.
   * @type {number}
   */
  scaleExtra: 2.5,

  /**
   * How much scrolling it takes before closing out.
   * @type {number}
   */
  scrollThreshold: 40,

  /**
   * The z-index that the overlay will be added with.
   * @type {number}
   */
  zIndex: 998,

  /**
   * Scale (zoom in) to given width and height. Ignore scaleBase if set.
   * Alternatively, provide a percentage value relative to the original image size.
   * @type {Object|String}
   * @example
   * customSize: { width: 800, height: 400 }
   * customSize: 100%
   */
  customSize: noop,

  /**
   * A callback function that will be called when a target is opened and
   * transition has ended. It will get the target element as the argument.
   * @type {Function}
   */
  onOpen: noop,

  /**
   * Same as above, except fired when closed.
   * @type {Function}
   */
  onClose: noop,

  /**
   * Same as above, except fired when grabbed.
   * @type {Function}
   */
  onGrab: noop,

  /**
   * Same as above, except fired when moved.
   * @type {Function}
   */
  onMove: noop,

  /**
   * Same as above, except fired when released.
   * @type {Function}
   */
  onRelease: noop,

  /**
   * A callback function that will be called before open.
   * @type {Function}
   */
  onBeforeOpen: noop,

  /**
   * A callback function that will be called before close.
   * @type {Function}
   */
  onBeforeClose: noop,

  /**
   * A callback function that will be called before grab.
   * @type {Function}
   */
  onBeforeGrab: noop,

  /**
   * A callback function that will be called before release.
   * @type {Function}
   */
  onBeforeRelease: noop,

  /**
   * A callback function that will be called when the hi-res image is loading.
   * @type {Function}
   */
  onImageLoading: noop,

  /**
   * A callback function that will be called when the hi-res image is loaded.
   * @type {Function}
   */
  onImageLoaded: noop
}
